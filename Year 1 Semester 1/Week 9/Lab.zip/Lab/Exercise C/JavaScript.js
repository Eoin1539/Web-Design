function popup1(){
	alert("This is an alert!");
}

function popup2(){
	prompt("This is a prompt!");
}

function popup3(){
	confirm("This is a confirm box!");
}
